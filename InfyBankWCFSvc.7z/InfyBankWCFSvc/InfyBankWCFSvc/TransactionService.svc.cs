﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using InfyBankWCFSvc.DbModels;
using InfyBankWCFSvc.ResponseEntites;
using InfyBankWCFSvc.Bc;

namespace InfyBankWCFSvc
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "TransactionService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select TransactionService.svc or TransactionService.svc.cs at the Solution Explorer and start debugging.
    public class TransactionService : ITransactionService
    {
        public TransactionBc bc { get; set; }

        public TransactionService()
        {
            this.bc = new TransactionBc();
        }

        
        public TransactionModels.TransactionFeedback AddTransaction(long userId, decimal amount, Transaction.TransactionType transactionType)
        {
            return this.bc.AddTransaction(userId,amount,transactionType);
        }

        public TransactionModels.TransactionFeedback Deposit(long userId, decimal amount)
        {
            return this.bc.Deposit(userId, amount);
        }

        public decimal GetCurrentBalanceForUser(long userId)
        {
            return this.bc.GetCurrentBalanceForUser(userId);
        }

        public Transaction GetLastTransactionForUser(long userId)
        {
            return this.bc.GetLastTransactionForUser(userId);
        }

        //public IEnumerable<Transaction> GetTransactionsForUser(long userId)
        //{
        //    return this.bc.GetTransactionsForUser(userId);
        //}

        public IEnumerable<Transaction> GetTransactionsForUser(long userId, int page)
        {
            if(page == 0)
            {
                return this.bc.GetTransactionsForUser(userId);
            }
            else
            {
                return this.bc.GetTransactionsForUser(userId, page);
            }
            
        }

        public User GetUser(long id)
        {
            return this.GetUser(id);
        }

        public User GetUserWithTransactions(long userId)
        {
            throw new NotImplementedException();
        }

        public TransactionModels.TransactionFeedback Withdraw(long userId, decimal amount)
        {
            throw new NotImplementedException();
        }
    }
}
