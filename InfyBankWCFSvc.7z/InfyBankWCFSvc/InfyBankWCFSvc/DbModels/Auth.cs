﻿using System;
using System.ComponentModel.DataAnnotations;

namespace InfyBankWCFSvc.DbModels
{
    public class Auth
    {
        [Key]
        public long Id { get; set; }
        public long UserId { get; set; }
        public Guid AuthKey { get; set; }
        public DateTime CreateDateTime { get; set; }
    }
}