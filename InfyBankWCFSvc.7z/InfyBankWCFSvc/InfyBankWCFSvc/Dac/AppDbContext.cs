﻿using InfyBankWCFSvc.DbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace InfyBankWCFSvc.Dac
{
    public class AppDbContext : DbContext
    {
        public virtual DbSet<Auth> Auths { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Transaction> Transactions { get; set; }

        public AppDbContext() : base("name=AppDbContextDb")
        { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
    
}

  