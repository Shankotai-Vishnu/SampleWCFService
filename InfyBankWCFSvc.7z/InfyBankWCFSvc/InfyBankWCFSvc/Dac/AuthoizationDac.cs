﻿using InfyBankWCFSvc.DbModels;
using InfyBankWCFSvc.ResponseEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InfyBankWCFSvc.Dac
{
    public class AuthoizationDac
    {
        public AuthModels.LoginFeedback Login(string username, string password)
        {
            // check if valid user details
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return new AuthModels.LoginFeedback
                {
                    Success = false,
                    Errors = "Username and Password cannot be empty."
                };
            }

            using (var db = new AppDbContext())
            {
                // check user name
                var user = db.Users.FirstOrDefault(x => string.Equals(x.Username, username, StringComparison.OrdinalIgnoreCase));
                if (user == null)
                {
                    // return error
                    return new AuthModels.LoginFeedback
                    {
                        Success = false,
                        Errors = $"Cannot find user {username}. Please register before logging in."
                    };
                }

                // check password
                if (user.Password != password)
                {
                    // return error
                    return new AuthModels.LoginFeedback
                    {
                        Success = false,
                        Errors = "Incorrect password."
                    };
                }

                // if here valid password. set as authenticated
                var auth = new Auth
                {
                    UserId = user.Id,
                    AuthKey = Guid.NewGuid(),
                    CreateDateTime = DateTime.Now
                };

                db.Auths.Add(auth);
                db.SaveChanges();

                // return success
                return new AuthModels.LoginFeedback()
                {
                    Success = true,
                    AuthKey = auth.AuthKey,
                    UserId = user.Id
                };
            }
        }

        // logout all user sessions by user name
        public void Logout(string username)
        {
            using (var db = new AppDbContext())
            {
                var user = db.Users.FirstOrDefault(x => x.Username.ToLower() == username.ToLower());
                if (user != null)
                {
                    Logout(user.Id);
                }

            }
        }

        // logout all user sessions by id
        public void Logout(long userId)
        {
            using (var db = new AppDbContext())
            {
                var auth = db.Auths.FirstOrDefault(x => x.UserId == userId);
                // check if exists
                if (auth != null)
                {
                    // remove authentication
                    //db.Remove(auth);
                    db.SaveChanges();
                }
            }
        }

        // functtion to check if a user is authenticated
        public bool IsAuthenticated(Guid authKey)
        {
            using (var db = new AppDbContext())
            {
                var auth = db.Auths.FirstOrDefault(x => x.AuthKey == authKey);
                return auth != null;
            }
        }

        public AuthModels.RegisterFeedback Register(User newUser)
        {
            // check if valid user
            if (string.IsNullOrEmpty(newUser.Username) || string.IsNullOrEmpty(newUser.Password))
            {
                return new AuthModels.RegisterFeedback
                {
                    Success = false,
                    Username = newUser.Username,
                    Errors = "Username and Password cannot be empty."
                };
            }

            using (var db = new AppDbContext())
            {
                // check if username already exists
                var prevUser = db.Users.FirstOrDefault(x => string.Equals(x.Username, newUser.Username, StringComparison.OrdinalIgnoreCase));
                if (prevUser != null)
                {
                    return new AuthModels.RegisterFeedback
                    {
                        Success = false,
                        Username = newUser.Username,
                        Errors = "Username already exists. Please use different Username."
                    };
                }

                // if no errors add user
                newUser.Id = 0;
                newUser.CreateDateTime = DateTime.Now;
                db.Users.Add(newUser);
                db.SaveChanges();

                // return success
                return new AuthModels.RegisterFeedback
                {
                    Success = true,
                    Username = newUser.Username
                };
            }
        }

        


    }
}