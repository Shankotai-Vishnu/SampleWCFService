﻿using InfyBankWCFSvc.DbModels;
using InfyBankWCFSvc.ResponseEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace InfyBankWCFSvc
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ITransactionService" in both code and config file together.
    [ServiceContract]
    public interface ITransactionService
    {
        [OperationContract]
        User GetUser(long id);

        [OperationContract]
        User GetUserWithTransactions(long userId);

        [OperationContract]
        decimal GetCurrentBalanceForUser(long userId);

        [OperationContract]
        Transaction GetLastTransactionForUser(long userId);

        //[OperationContract]
        //IEnumerable<Transaction> GetTransactionsForUser(long userId);

        [OperationContract]
        IEnumerable<Transaction> GetTransactionsForUser(long userId, int page);

        [OperationContract]
        TransactionModels.TransactionFeedback Deposit(long userId, decimal amount);

        [OperationContract]
        TransactionModels.TransactionFeedback Withdraw(long userId, decimal amount);

        [OperationContract]
        TransactionModels.TransactionFeedback AddTransaction(long userId, decimal amount, Transaction.TransactionType transactionType);
    }
}
