﻿using InfyBankWCFSvc.Dac;
using InfyBankWCFSvc.DbModels;
using InfyBankWCFSvc.ResponseEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InfyBankWCFSvc.Bc
{
    public class TransactionBc
    {
        public TransactionDac dac { get; set; }

        public TransactionBc()
        {
            this.dac = new TransactionDac();
        }

        public User GetUser(long id)
        {
            return this.dac.GetUser(id);
        }

        public User GetUserWithTransactions(long userId)
        {
            return this.GetUserWithTransactions(userId);
        }

        public decimal GetCurrentBalanceForUser(long userId)
        {
            return this.GetCurrentBalanceForUser(userId);
        }

        public Transaction GetLastTransactionForUser(long userId)
        {
            return this.dac.GetLastTransactionForUser(userId);
        }

        public IEnumerable<Transaction> GetTransactionsForUser(long userId)
        {
            return this.GetTransactionsForUser(userId);
        }

        public IEnumerable<Transaction> GetTransactionsForUser(long userId, int page)
        {
            return this.GetTransactionsForUser(userId, page);
        }


        public TransactionModels.TransactionFeedback Deposit(long userId, decimal amount)
        {
            return this.dac.Deposit(userId, amount);
        }

        public TransactionModels.TransactionFeedback Withdraw(long userId, decimal amount)
        {
            return this.dac.Withdraw(userId, amount);
        }

        public TransactionModels.TransactionFeedback AddTransaction(long userId, decimal amount, Transaction.TransactionType transactionType)
        {
            return this.AddTransaction(userId, amount, transactionType);
        }

    }
}