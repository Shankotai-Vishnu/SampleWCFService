﻿using InfyBankWCFSvc.ResponseEntites;
using InfyBankWCFSvc.Dac;
using System;
using InfyBankWCFSvc.DbModels;

namespace InfyBankWCFSvc.Bc
{
    public class AuthorizationBc
    {
        public AuthoizationDac dac { get; set; }
        public AuthorizationBc()
        {
            this.dac = new AuthoizationDac();
        }
        public AuthModels.LoginFeedback Login(string username, string password)
        {
            return this.dac.Login(username, password);
        }

        public void Logout(long userid)
        {
            this.dac.Logout(userid);
        }

        public void Logout(string username)
        {
            this.dac.Logout(username);
        }

        public bool IsAuthenticated(Guid authKey)
        {
            return this.dac.IsAuthenticated(authKey);
        }

        public AuthModels.RegisterFeedback Register(User newUser)
        {
            return this.dac.Register(newUser);
        }

    }
}