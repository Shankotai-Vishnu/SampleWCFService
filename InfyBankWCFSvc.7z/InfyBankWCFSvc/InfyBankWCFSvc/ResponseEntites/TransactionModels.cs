﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InfyBankWCFSvc.ResponseEntites
{
    public class TransactionModels
    {
        public class TransactionFeedback
        {
            public DbModels.Transaction.TransactionType TransactionType { get; set; }
            public string Errors { get; set; }
            public bool Success { get; set; }
        }
    }
}